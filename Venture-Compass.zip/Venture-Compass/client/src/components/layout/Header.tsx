import { Search, Bell, Command, Sun, Filter } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function Header() {
  return (
    <header className="h-16 border-b border-slate-100 bg-white/80 backdrop-blur-lg sticky top-0 z-30 flex items-center justify-between px-8">
      <div className="flex-1 max-w-2xl">
        <div className="relative group">
          <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none text-slate-400 group-focus-within:text-slate-900 transition-colors">
            <Search className="w-4 h-4" />
          </div>
          <Input 
            placeholder="Search founders, industries, or companies..." 
            className="w-full pl-10 pr-16 bg-slate-100/50 border-transparent hover:bg-slate-100 focus:bg-white focus:border-slate-200 focus:ring-4 focus:ring-slate-900/5 transition-all rounded-xl h-10 text-sm placeholder:text-slate-400"
            data-testid="input-global-search"
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none">
            <kbd className="hidden sm:inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-1.5 py-0.5 font-mono text-[10px] font-bold text-slate-400 shadow-sm">
              <Command className="w-2.5 h-2.5" /> K
            </kbd>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="rounded-full text-slate-400 hover:bg-slate-100 hover:text-slate-900 transition-all">
          <Sun className="w-5 h-5" />
        </Button>
        <Button variant="ghost" size="icon" className="relative rounded-full text-slate-400 hover:bg-slate-100 hover:text-slate-900 transition-all">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2.5 right-2.5 w-1.5 h-1.5 rounded-full bg-rose-500 ring-2 ring-white"></span>
        </Button>
        <div className="h-8 w-px bg-slate-100 mx-2" />
        <Button className="rounded-xl px-5 font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-lg shadow-slate-200 transition-all active:scale-95" data-testid="button-add-company">
          Add Target
        </Button>
      </div>
    </header>
  );
}
