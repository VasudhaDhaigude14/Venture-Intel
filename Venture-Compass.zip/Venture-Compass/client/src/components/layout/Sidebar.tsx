import { Link, useLocation } from "wouter";
import { 
  Building2, 
  ListOrdered, 
  Search, 
  Star, 
  Settings, 
  LayoutDashboard,
  PlusCircle,
  TrendingUp,
  History
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const mainNav = [
  { icon: LayoutDashboard, label: "Overview", href: "/" },
  { icon: Building2, label: "Companies", href: "/companies" },
  { icon: ListOrdered, label: "Lists", href: "/lists" },
];

const secondaryNav = [
  { icon: Star, label: "Saved Searches", href: "/saved" },
  { icon: History, label: "Recent Activity", href: "/activity" },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 border-r bg-white/50 backdrop-blur-xl h-screen sticky top-0 flex flex-col z-40">
      <div className="h-16 flex items-center px-6 mb-2">
        <Link href="/">
          <a className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-lg bg-black flex items-center justify-center text-white shadow-lg shadow-black/10 group-hover:scale-105 transition-transform">
              <TrendingUp className="w-4 h-4" />
            </div>
            <span className="font-bold text-lg tracking-tight text-slate-900">Venture Intel</span>
          </a>
        </Link>
      </div>

      <div className="flex-1 px-4 space-y-8 py-4">
        {/* Main Navigation */}
        <nav className="space-y-1">
          {mainNav.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <a
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 group relative",
                    isActive
                      ? "bg-slate-900 text-white shadow-md shadow-slate-200"
                      : "text-slate-500 hover:bg-slate-100 hover:text-slate-900"
                  )}
                  data-testid={`nav-link-${item.label.toLowerCase()}`}
                >
                  <item.icon className={cn("w-4 h-4", isActive ? "text-white" : "text-slate-400 group-hover:text-slate-900")} />
                  {item.label}
                  {isActive && <div className="absolute right-2 w-1.5 h-1.5 rounded-full bg-white/40" />}
                </a>
              </Link>
            );
          })}
        </nav>

        {/* Discovery & Tools */}
        <div className="space-y-3">
          <h4 className="px-3 text-[10px] font-bold uppercase tracking-widest text-slate-400/80">Discovery</h4>
          <nav className="space-y-1">
            {secondaryNav.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <a
                    className={cn(
                      "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 group",
                      isActive
                        ? "bg-slate-100 text-slate-900"
                        : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                    )}
                  >
                    <item.icon className="w-4 h-4 text-slate-400 group-hover:text-slate-600" />
                    {item.label}
                  </a>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Create List CTA */}
        <div className="px-3">
          <button className="w-full flex items-center justify-center gap-2 py-2.5 border border-dashed border-slate-300 rounded-lg text-xs font-semibold text-slate-500 hover:border-slate-900 hover:text-slate-900 transition-all group">
            <PlusCircle className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
            Create New List
          </button>
        </div>
      </div>

      {/* User Profile Footer */}
      <div className="p-4 mt-auto border-t border-slate-100 bg-slate-50/50">
        <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-white transition-colors cursor-pointer border border-transparent hover:border-slate-200 hover:shadow-sm group">
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-slate-200 to-slate-100 border border-slate-200 flex items-center justify-center text-xs font-bold text-slate-600">
            JD
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-slate-900 truncate leading-none mb-1">Jane Doe</p>
            <p className="text-[11px] text-slate-500 truncate font-medium">Principal @ Sequoia</p>
          </div>
          <Settings className="w-4 h-4 text-slate-300 group-hover:text-slate-600 transition-colors" />
        </div>
      </div>
    </aside>
  );
}
