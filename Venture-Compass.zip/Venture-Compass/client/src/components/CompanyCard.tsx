import { Building2, Users, MapPin, TrendingUp, AlertCircle, CheckCircle2, DollarSign, ArrowUpRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { type Company } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export function CompanyCard({ company }: { company: Company }) {
  return (
    <Card className="glass-card hover-lift group overflow-hidden border-slate-100 flex flex-col h-full">
      <CardContent className="p-0 flex flex-col h-full">
        <div className="p-6 flex-1">
          <div className="flex items-start justify-between mb-5">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-slate-950 text-white flex items-center justify-center font-bold text-xl shadow-lg shadow-slate-200 border border-white/10">
                {company.logo}
              </div>
              <div>
                <h3 className="font-bold text-lg leading-none tracking-tight mb-2 text-slate-900 group-hover:text-black transition-colors">
                  {company.name}
                </h3>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="font-semibold text-[10px] uppercase tracking-wider px-2 py-0.5 bg-slate-100 text-slate-600 border-none">
                    {company.industry}
                  </Badge>
                  <span className="w-1 h-1 rounded-full bg-slate-300" />
                  <span className="text-xs font-medium text-slate-500">{company.stage}</span>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="rounded-full bg-slate-50 opacity-0 group-hover:opacity-100 transition-all hover:bg-slate-900 hover:text-white">
              <ArrowUpRight className="w-4 h-4" />
            </Button>
          </div>

          <p className="text-sm text-slate-500 mb-6 leading-relaxed font-medium">
            {company.description}
          </p>

          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-slate-400">
                <MapPin className="w-3.5 h-3.5" />
                <span className="font-medium">{company.location}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-400">
                <Users className="w-3.5 h-3.5" />
                <span className="font-medium">{company.employees} HQ</span>
              </div>
            </div>
            
            <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-100/50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">Latest Funding</span>
              </div>
              <span className="text-sm font-black text-emerald-900">{company.lastFunding.split(' ')[0]}</span>
            </div>
          </div>
        </div>

        {/* Signals Section */}
        <div className="bg-slate-50/80 px-6 py-5 border-t border-slate-100 mt-auto">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-slate-900" />
            <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Live Intel Signals</h4>
          </div>
          <div className="space-y-4">
            {company.signals.map((signal) => (
              <div key={signal.id} className="flex gap-4">
                <div className={cn(
                  "w-1 h-8 rounded-full shrink-0 mt-1",
                  signal.impact === 'positive' ? "bg-emerald-400" : 
                  signal.impact === 'negative' ? "bg-rose-400" : "bg-slate-300"
                )} />
                <div className="flex-1 min-w-0">
                  <p className={cn(
                    "text-xs leading-relaxed font-semibold line-clamp-2",
                    signal.impact === 'negative' ? "text-rose-600" : "text-slate-700"
                  )}>
                    {signal.content}
                  </p>
                  <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-tight">{signal.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
