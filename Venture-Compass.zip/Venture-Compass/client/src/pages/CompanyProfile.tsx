import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";
import { mockCompanies } from "@/lib/mock-data";
import { useRoute } from "wouter";
import { 
  Building2, 
  MapPin, 
  Users, 
  Globe, 
  ArrowLeft, 
  TrendingUp,
  Briefcase,
  Layers,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

export default function CompanyProfile() {
  const [, params] = useRoute("/companies/:id");
  const company = mockCompanies.find(c => c.id === params?.id);

  if (!company) return <div>Company not found</div>;

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <Header />
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-5xl mx-auto">
            <Link href="/companies">
              <a className="inline-flex items-center gap-2 text-sm font-bold text-slate-400 hover:text-slate-900 transition-colors mb-8 group">
                <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                Back to Companies
              </a>
            </Link>

            <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden mb-8">
              <div className="p-8 md:p-12">
                <div className="flex flex-col md:flex-row gap-8 items-start justify-between mb-12">
                  <div className="flex items-center gap-6">
                    <div className="w-24 h-24 rounded-3xl bg-slate-950 text-white flex items-center justify-center font-bold text-4xl shadow-2xl shadow-slate-200 border border-white/10">
                      {company.logo}
                    </div>
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <h1 className="text-3xl font-black tracking-tight text-slate-900">{company.name}</h1>
                        <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-none font-bold uppercase tracking-widest text-[10px] px-2 py-0.5">
                          Verified
                        </Badge>
                      </div>
                      <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-slate-500 font-semibold text-sm">
                        <span className="flex items-center gap-1.5"><Layers className="w-4 h-4" /> {company.industry}</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-200" />
                        <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4" /> {company.location}</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-200" />
                        <span className="flex items-center gap-1.5 underline decoration-slate-200"><Globe className="w-4 h-4" /> {company.website}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-3 w-full md:w-auto">
                    <Button variant="outline" className="flex-1 md:flex-none rounded-xl font-bold border-slate-200">Track</Button>
                    <Button className="flex-1 md:flex-none rounded-xl font-bold bg-slate-900 text-white shadow-xl shadow-slate-200">Enrich Live</Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                  <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Current Stage</p>
                    <p className="text-xl font-black text-slate-900">{company.stage}</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Employee Count</p>
                    <p className="text-xl font-black text-slate-900">{company.employees}</p>
                  </div>
                  <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">Total Raised</p>
                    <p className="text-xl font-black text-slate-900">{company.lastFunding.split(' ')[0]}</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <h2 className="text-xl font-black tracking-tight text-slate-900">About {company.name}</h2>
                  <p className="text-lg text-slate-600 leading-relaxed font-medium max-w-3xl">
                    {company.description} {company.name} is building the next generation of {company.industry.toLowerCase()} solutions, focused on scalability and high-impact performance.
                  </p>
                </div>
              </div>
              
              <div className="bg-slate-50 border-t border-slate-100 p-8 md:p-12">
                <div className="flex items-center gap-2 mb-8">
                  <TrendingUp className="w-5 h-5 text-slate-900" />
                  <h2 className="text-xl font-black tracking-tight text-slate-900">Company Signals</h2>
                </div>
                
                <div className="space-y-4">
                  {company.signals.map(signal => (
                    <div key={signal.id} className="bg-white p-5 rounded-2xl border border-slate-200 flex items-start gap-4 hover:shadow-md transition-all group">
                      <div className="mt-1 w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center group-hover:bg-slate-900 transition-colors">
                        {signal.type === 'funding' && <TrendingUp className="w-5 h-5 text-slate-600 group-hover:text-white" />}
                        {signal.type === 'hiring' && <Briefcase className="w-5 h-5 text-slate-600 group-hover:text-white" />}
                        {signal.type === 'news' && <Globe className="w-5 h-5 text-slate-600 group-hover:text-white" />}
                        {signal.type === 'product' && <Layers className="w-5 h-5 text-slate-600 group-hover:text-white" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{signal.type}</span>
                          <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1"><Calendar className="w-3 h-3" /> {signal.date}</span>
                        </div>
                        <p className="font-bold text-slate-900">{signal.content}</p>
                      </div>
                    </div>
                  ))}
                  {company.signals.length === 0 && (
                    <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-200">
                      <p className="text-slate-400 font-bold tracking-tight italic">No recent signals detected.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
