import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";
import { CompanyCard } from "@/components/CompanyCard";
import { mockCompanies, liveEnrichmentFeed } from "@/lib/mock-data";
import { Activity, Zap, TrendingUp, Filter, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  return (
    <div className="flex min-h-screen bg-background text-foreground selection:bg-primary/20">
      <Sidebar />
      
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <Header />
        
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-[1600px] mx-auto p-8">
            
            <div className="flex items-end justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold tracking-tight mb-2">Company Discovery</h1>
                <p className="text-muted-foreground text-lg">Track and enrich 10k+ startups in real-time.</p>
              </div>
              
              <div className="flex items-center gap-3">
                <Button variant="outline" className="gap-2 text-muted-foreground border-border/50 bg-background hover:bg-muted" data-testid="button-filter">
                  <Filter className="w-4 h-4" /> Filters
                </Button>
                <Button variant="outline" className="gap-2 text-muted-foreground border-border/50 bg-background hover:bg-muted" data-testid="button-sort">
                  <SlidersHorizontal className="w-4 h-4" /> Sort
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
              
              {/* Main Company Grid */}
              <div className="xl:col-span-8 space-y-6">
                <div className="flex items-center gap-2 pb-2 border-b border-border/50">
                  <Zap className="w-5 h-5 text-primary" />
                  <h2 className="text-lg font-semibold">Recommended for you</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {mockCompanies.map(company => (
                    <CompanyCard key={company.id} company={company} />
                  ))}
                </div>
              </div>

              {/* Live Enrichment Feed Sidebar */}
              <div className="xl:col-span-4">
                <div className="sticky top-8 bg-card border border-border/50 rounded-xl overflow-hidden shadow-sm">
                  <div className="px-6 py-5 border-b border-border/50 bg-muted/10 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="relative flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-primary"></span>
                      </div>
                      <h2 className="font-semibold text-lg">Live Enrichment</h2>
                    </div>
                    <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-md">
                      Auto-updating
                    </span>
                  </div>
                  
                  <div className="p-6 space-y-6 max-h-[calc(100vh-280px)] overflow-y-auto">
                    {liveEnrichmentFeed.map((feedItem, idx) => (
                      <div key={feedItem.id} className="relative pl-6 pb-6 last:pb-0">
                        {/* Timeline line */}
                        {idx !== liveEnrichmentFeed.length - 1 && (
                          <div className="absolute left-[11px] top-6 bottom-0 w-[2px] bg-border" />
                        )}
                        
                        {/* Timeline node */}
                        <div className="absolute left-0 top-1.5 w-6 h-6 rounded-full bg-background border-2 border-muted-foreground/20 flex items-center justify-center">
                          <Activity className="w-3 h-3 text-muted-foreground" />
                        </div>
                        
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-xs font-medium text-primary uppercase tracking-wider">
                              {feedItem.type}
                            </span>
                            <span className="text-xs text-muted-foreground">{feedItem.date}</span>
                          </div>
                          <p className="text-sm text-foreground leading-relaxed">{feedItem.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
            </div>
            
          </div>
        </div>
      </main>
    </div>
  );
}
