import { useState, useMemo } from "react";
import { Sidebar } from "@/components/layout/Sidebar";
import { Header } from "@/components/layout/Header";
import { mockCompanies } from "@/lib/mock-data";
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  ExternalLink, 
  ChevronLeft, 
  ChevronRight,
  MoreHorizontal
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLocation } from "wouter";

export default function Companies() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [industry, setIndustry] = useState("all");
  const [sortField, setSortField] = useState<"name" | "industry" | "location">("name");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [page, setPage] = useState(1);
  const itemsPerPage = 8;

  const industries = useMemo(() => {
    const set = new Set(mockCompanies.map(c => c.industry));
    return ["all", ...Array.from(set)];
  }, []);

  const filteredCompanies = useMemo(() => {
    return mockCompanies
      .filter(c => {
        const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) || 
                             c.industry.toLowerCase().includes(search.toLowerCase());
        const matchesIndustry = industry === "all" || c.industry === industry;
        return matchesSearch && matchesIndustry;
      })
      .sort((a, b) => {
        const valA = a[sortField].toLowerCase();
        const valB = b[sortField].toLowerCase();
        if (sortOrder === "asc") return valA > valB ? 1 : -1;
        return valA < valB ? 1 : -1;
      });
  }, [search, industry, sortField, sortOrder]);

  const totalPages = Math.ceil(filteredCompanies.length / itemsPerPage);
  const paginatedCompanies = filteredCompanies.slice((page - 1) * itemsPerPage, page * itemsPerPage);

  const toggleSort = (field: "name" | "industry" | "location") => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <Header />
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-8">
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">Companies</h1>
              <p className="text-slate-500">Manage and explore your curated list of target companies.</p>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="flex flex-1 items-center gap-3 w-full max-w-md">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input 
                      placeholder="Search name or industry..." 
                      className="pl-9 bg-slate-50 border-transparent focus:bg-white transition-all h-9 text-sm"
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                    />
                  </div>
                  <Select value={industry} onValueChange={setIndustry}>
                    <SelectTrigger className="w-[160px] h-9 bg-slate-50 border-transparent text-sm">
                      <SelectValue placeholder="Industry" />
                    </SelectTrigger>
                    <SelectContent>
                      {industries.map(ind => (
                        <SelectItem key={ind} value={ind} className="capitalize">
                          {ind === "all" ? "All Industries" : ind}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="h-9 gap-2 text-slate-600">
                    <Filter className="w-4 h-4" /> Filters
                  </Button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-slate-50/50">
                    <TableRow className="hover:bg-transparent border-slate-100">
                      <TableHead 
                        className="w-[300px] cursor-pointer group"
                        onClick={() => toggleSort("name")}
                      >
                        <div className="flex items-center gap-2 text-slate-900 font-bold">
                          Name <ArrowUpDown className="w-3.5 h-3.5 text-slate-300 group-hover:text-slate-900 transition-colors" />
                        </div>
                      </TableHead>
                      <TableHead 
                        className="cursor-pointer group"
                        onClick={() => toggleSort("industry")}
                      >
                        <div className="flex items-center gap-2 text-slate-900 font-bold">
                          Industry <ArrowUpDown className="w-3.5 h-3.5 text-slate-300 group-hover:text-slate-900 transition-colors" />
                        </div>
                      </TableHead>
                      <TableHead 
                        className="cursor-pointer group"
                        onClick={() => toggleSort("location")}
                      >
                        <div className="flex items-center gap-2 text-slate-900 font-bold">
                          Location <ArrowUpDown className="w-3.5 h-3.5 text-slate-300 group-hover:text-slate-900 transition-colors" />
                        </div>
                      </TableHead>
                      <TableHead className="text-slate-900 font-bold">Website</TableHead>
                      <TableHead className="w-[80px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedCompanies.map((company) => (
                      <TableRow 
                        key={company.id} 
                        className="cursor-pointer hover:bg-slate-50 transition-colors border-slate-100 group"
                        onClick={() => setLocation(`/companies/${company.id}`)}
                      >
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-xs shadow-sm">
                              {company.logo}
                            </div>
                            <span className="font-semibold text-slate-900">{company.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-slate-500 font-medium">{company.industry}</span>
                        </TableCell>
                        <TableCell>
                          <span className="text-slate-500 font-medium">{company.location}</span>
                        </TableCell>
                        <TableCell>
                          <a 
                            href={`https://${company.website}`} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center gap-1.5 text-slate-400 hover:text-slate-900 transition-colors group/link"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <span className="text-sm font-medium underline underline-offset-4 decoration-slate-200 group-hover/link:decoration-slate-900">{company.website}</span>
                            <ExternalLink className="w-3 h-3 opacity-0 group-hover/link:opacity-100 transition-opacity" />
                          </a>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                            <MoreHorizontal className="w-4 h-4 text-slate-400" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/30">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-widest">
                  Showing {(page - 1) * itemsPerPage + 1} to {Math.min(page * itemsPerPage, filteredCompanies.length)} of {filteredCompanies.length}
                </p>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-8 w-8 rounded-lg border-slate-200"
                    disabled={page === 1}
                    onClick={() => setPage(page - 1)}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <div className="flex items-center gap-1 px-2">
                    {Array.from({ length: totalPages }).map((_, i) => (
                      <button
                        key={i}
                        className={cn(
                          "w-8 h-8 rounded-lg text-xs font-bold transition-all",
                          page === i + 1 ? "bg-slate-900 text-white shadow-md shadow-slate-200" : "text-slate-400 hover:text-slate-900 hover:bg-white"
                        )}
                        onClick={() => setPage(i + 1)}
                      >
                        {i + 1}
                      </button>
                    ))}
                  </div>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="h-8 w-8 rounded-lg border-slate-200"
                    disabled={page === totalPages}
                    onClick={() => setPage(page + 1)}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
