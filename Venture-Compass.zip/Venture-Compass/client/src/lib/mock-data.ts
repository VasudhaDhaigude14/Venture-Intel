export interface Company {
  id: string;
  name: string;
  logo: string;
  industry: string;
  stage: string;
  location: string;
  employees: number;
  lastFunding: string;
  signals: Signal[];
  description: string;
  website: string;
}

export interface Signal {
  id: string;
  type: 'funding' | 'hiring' | 'news' | 'product';
  content: string;
  date: string;
  impact: 'positive' | 'neutral' | 'negative';
}

export const mockCompanies: Company[] = [
  {
    id: '1',
    name: 'Nexus API',
    logo: 'N',
    industry: 'DevTools',
    stage: 'Series A',
    location: 'San Francisco, CA',
    employees: 45,
    lastFunding: '$12M (2 mos ago)',
    description: 'Unified API for fintech integrations and payment routing.',
    website: 'nexusapi.io',
    signals: [
      { id: 's1', type: 'hiring', content: 'Opened 5 new engineering roles', date: '2 days ago', impact: 'positive' },
      { id: 's2', type: 'news', content: 'Partnered with Stripe', date: '1 week ago', impact: 'positive' }
    ]
  },
  {
    id: '2',
    name: 'Aura Health',
    logo: 'A',
    industry: 'HealthTech',
    stage: 'Seed',
    location: 'New York, NY',
    employees: 18,
    lastFunding: '$3.5M (8 mos ago)',
    description: 'AI-driven personalized mental wellness and coaching platform.',
    website: 'aurahealth.ai',
    signals: [
      { id: 's3', type: 'product', content: 'Launched B2B enterprise tier', date: '3 days ago', impact: 'positive' },
      { id: 's4', type: 'hiring', content: 'VP of Sales hired', date: '2 weeks ago', impact: 'positive' }
    ]
  },
  {
    id: '3',
    name: 'Orbit Logistics',
    logo: 'O',
    industry: 'Supply Chain',
    stage: 'Series B',
    location: 'Chicago, IL',
    employees: 120,
    lastFunding: '$30M (1 yr ago)',
    description: 'Predictive supply chain analytics for e-commerce brands.',
    website: 'orbitlogistics.com',
    signals: [
      { id: 's5', type: 'news', content: 'Mentioned in TechCrunch supply chain report', date: '5 hours ago', impact: 'neutral' }
    ]
  },
  {
    id: '4',
    name: 'Vanguard Sec',
    logo: 'V',
    industry: 'Cybersecurity',
    stage: 'Pre-Seed',
    location: 'Austin, TX',
    employees: 8,
    lastFunding: '$1M (1 mo ago)',
    description: 'Zero-trust infrastructure for decentralized teams.',
    website: 'vanguardsec.io',
    signals: [
      { id: 's6', type: 'funding', content: 'Closed $1M pre-seed round led by XYZ Cap', date: '1 month ago', impact: 'positive' }
    ]
  },
  {
    id: '5',
    name: 'Lumina Data',
    logo: 'L',
    industry: 'Data Infrastructure',
    stage: 'Series A',
    location: 'Remote',
    employees: 32,
    lastFunding: '$15M (5 mos ago)',
    description: 'Real-time data streaming and transformation engine.',
    website: 'lumina.data',
    signals: [
      { id: 's7', type: 'hiring', content: 'Hiring growth has slowed by 20%', date: '1 week ago', impact: 'negative' },
      { id: 's8', type: 'product', content: 'Released v2.0 of core streaming engine', date: '3 weeks ago', impact: 'positive' }
    ]
  },
  {
    id: '6',
    name: 'CloudScale',
    logo: 'C',
    industry: 'DevOps',
    stage: 'Series C',
    location: 'Seattle, WA',
    employees: 250,
    lastFunding: '$80M (6 mos ago)',
    description: 'Automated cloud infrastructure scaling and cost optimization.',
    website: 'cloudscale.tech',
    signals: [{ id: 's9', type: 'news', content: 'Acquired small monitoring startup', date: '2 days ago', impact: 'positive' }]
  },
  {
    id: '7',
    name: 'GreenPulse',
    logo: 'G',
    industry: 'CleanTech',
    stage: 'Series A',
    location: 'Denver, CO',
    employees: 35,
    lastFunding: '$10M (3 mos ago)',
    description: 'Carbon tracking software for manufacturing supply chains.',
    website: 'greenpulse.eco',
    signals: []
  },
  {
    id: '8',
    name: 'BioSynth',
    logo: 'B',
    industry: 'BioTech',
    stage: 'Seed',
    location: 'Boston, MA',
    employees: 12,
    lastFunding: '$4M (1 yr ago)',
    description: 'Synthetic biology platform for sustainable material design.',
    website: 'biosynth.bio',
    signals: []
  },
  {
    id: '9',
    name: 'FinFlow',
    logo: 'F',
    industry: 'FinTech',
    stage: 'Series B',
    location: 'London, UK',
    employees: 85,
    lastFunding: '$25M (9 mos ago)',
    description: 'Cross-border payment infrastructure for emerging markets.',
    website: 'finflow.payments',
    signals: []
  },
  {
    id: '10',
    name: 'SecureNode',
    logo: 'S',
    industry: 'Cybersecurity',
    stage: 'Series A',
    location: 'Tel Aviv, IL',
    employees: 55,
    lastFunding: '$18M (4 mos ago)',
    description: 'Next-gen firewall for cloud-native applications.',
    website: 'securenode.io',
    signals: []
  }
];

export const liveEnrichmentFeed: Signal[] = [
  { id: 'f1', type: 'funding', content: 'Nexus API rumored to be raising Series B', date: '10 mins ago', impact: 'positive' },
  { id: 'f2', type: 'news', content: 'Aura Health CEO speaking at HealthTech Summit', date: '1 hour ago', impact: 'neutral' },
  { id: 'f3', type: 'hiring', content: 'Orbit Logistics opens European HQ in London', date: '2 hours ago', impact: 'positive' },
  { id: 'f4', type: 'product', content: 'Vanguard Sec launches SOC2 compliance tool', date: '4 hours ago', impact: 'positive' },
  { id: 'f5', type: 'news', content: 'Data Privacy regulations may affect Lumina Data', date: '5 hours ago', impact: 'negative' },
];
